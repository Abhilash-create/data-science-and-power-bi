<img align = right height = 120 width = 120 src = https://www.thesparksfoundationsingapore.org/images/logo_small.png>

#  The Sparks Foundation Tasks


This repository contains the tasks that I completed while working as an intern for [The Sparks Foundation.](https://www.thesparksfoundationsingapore.org/)
- **Internship Category** - Data Science and Business Analytics
- **Internship Duration** - 1 Month 
- **Internship Type** - Work from Home

In this internship, we were provided a total of 2 Tasks and I was able to successfully complete all the 2 tasks within the given time-frame.

[<img align = right height = 50 width = 50 src = https://cdn4.iconfinder.com/data/icons/social-media-and-logos-11/32/Logo_Youtube-512.png>](https://youtu.be/N-EJXVJhYfo)
[<img align = right height = 50 width = 50 src = https://cdn4.iconfinder.com/data/icons/project-management-4-2/65/161-512.png>](https://github.com/Hemakokku/Data_analysis_projects/blob/main/Task-4%20-%20Exploratory%20Data%20Analysis%20-%20Terrorism.ipynb)
[<img align = right height = 50 width = 50 src = https://cdn4.iconfinder.com/data/icons/project-management-4-2/65/161-512.png>](https://github.com/Hemakokku/Data_analysis_projects/blob/main/Task_5_data_analysis_sports.ipynb)



### # Task-4 : Exploratory Data Analysis Terrorism


1.To perform Exploratory Data Analysis Terrorism

2.You can use R, Python,PowerBI or any other tool.



### # Task-5 : Exploratory Data Analysis Sports 
_Please click on the images on right side to view my solution._

1.To perform  Exploratory Data Analysis on Sports 

1. Data can be found at ***[Click Here](https://drive.google.com/file/d/18iDDIIZGt8eWxzqbyMIqcn5X7bHINuLw/view)***
1. You can use R, Python,PowerBI or any other tool.
